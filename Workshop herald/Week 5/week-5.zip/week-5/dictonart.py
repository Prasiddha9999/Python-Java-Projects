list=[]
for x in range(10):
    a=input("Enter a number")
    if (a < 100) and (a > 1):
        list.append+=a

