d = {}
key_list={}
def add_daily_temp(days,temp):
    if days not in d:
        d.update({days:temp})
    return d
for days in  range(7):
        temp=int(input("Enter average temperature"))
        add_daily_temp(days,temp)
for y in d:
    if d[y]>70 and d[y]<79:
        key_list = list(d.keys())
        
print (key_list)
