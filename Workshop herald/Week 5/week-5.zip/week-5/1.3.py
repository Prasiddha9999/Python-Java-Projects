list=[]
num=0
for x in range(10):
    name=input("Enter a name")
    list.append(name)
    for x in name:
        if x=="a":
            num+=1
print(list)
print(num)
