words=[]
items = input("Input comma separated sequence of words")
words=items.split(",")
print(words)
words.sort()
print(words)

