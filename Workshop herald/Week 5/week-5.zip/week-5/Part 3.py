d = {}
def add_daily_temp(day,temp):
    if day not in d:
        d.update({day:temp})
    return d
for x in  range(7):
        day=input("Enter the day")
        temp=input("Enter temperature")
        add_daily_temp(day,temp)
print(d)
    
