f=[]
c=[12,123,323,2321,121,34]
for x in c:
    far= (x *9/5) + 32
    f.append(far)

print (f)
