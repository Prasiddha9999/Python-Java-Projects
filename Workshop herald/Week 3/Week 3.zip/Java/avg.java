public class lets
{
public static double avg(double num1, double num2)
{
return (num1 + num2) / 2;
}
public static void main(String[] args)
{
double n1 = 37, n2 = 108;
double result = avg(n1,n2);
System.out.printf("Average is %f", result);
}
}