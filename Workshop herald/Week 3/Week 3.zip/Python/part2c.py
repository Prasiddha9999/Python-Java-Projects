def int_to_string(value):
    return value;
n1 = int(input("Enter value"))
val = str(int_to_string(n1))
print("The enter value in string is", val)
