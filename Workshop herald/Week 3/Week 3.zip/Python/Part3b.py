def display(num1, num2):
    return (num1, num2)
number1 = int(input("Enter the first number"))
number2 = int(input("Enter the second number"))
summ = number1 + number2
dif = number1 - number2
mult= number1 * number2
div = number1 / number2
mod = number1 % number2
print("Addition : ", summ,"Subtraction : ",dif,"Multiplication : ",mult,"Division :\n",div,"Modulus : ",mod)


         
