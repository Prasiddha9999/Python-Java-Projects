def hello_world(value):
    return value;
n1 = str(input("Enter value"))
val = hello_world(n1)
print("Hello World, my name is ", val)
