def print_ast(value):
    now = ("*"*value)
    return (now)
value = int(input("Enter value to print ast"))
val = print_ast(value)
print(val)
