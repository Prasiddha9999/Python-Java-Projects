def types(value):
    return (value)
value = input("Enter value")
val = types(value)
print("The enter value is ", val)
