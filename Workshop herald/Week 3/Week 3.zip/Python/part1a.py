def avg(num1, num2, num3):
    return (num1 + num2 + num3) /3.0
n1 = 37
n2 = 108
n3 = 67
average = avg(n1, n2, n3)
print('The average of number= %0.2f'%average)
