def avg(num1, num2):
    return (num1 + num2) /2.0
n1 = 37
n2 = 108
result = avg(n1, n2)
print('The average of number= %0.2f'%result)
