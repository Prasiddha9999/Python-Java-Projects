def squared(value):
    now = (value**2)
    return (now)
value = int(input("Enter value"))
val = squared(value)
print("The enter value is ", val)
