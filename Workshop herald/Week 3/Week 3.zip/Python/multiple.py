def multiplication_table():
     return()
print('', end='\t')
x = 1
while x <= 10:
     print(x ,end='\t')
     x += 1

y = 1
while y <= 10:
     print('')
     print(y,end='\t')
     z = 1
     while z <= 10:
          print(y*z ,end='\t')
          z += 1
     y += 1
print()
