num=int(input("Enter a number between 32 and 126 "))
utf=str(chr(num))
print("The UTF-8 character is ", utf)