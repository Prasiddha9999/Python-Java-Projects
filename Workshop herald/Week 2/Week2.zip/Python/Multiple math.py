num1=int(input("Enter a number"))
num2=int(input("Enter another number"))

sum = num1 + num2
diff = num1 - num2 
mult = num1 * num2
div = num1 / num2
mod = num1 % num2
expo = num1 ** num2 
print(sum)
print(diff)
print(mult)
print(mod)
print(expo)


