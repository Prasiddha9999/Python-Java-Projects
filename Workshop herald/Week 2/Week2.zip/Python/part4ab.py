k = 5
num = 0
num1 = num + k * 2
num2 = num + k * 2
print("num is ",num)
print(num1)
print(num2)
