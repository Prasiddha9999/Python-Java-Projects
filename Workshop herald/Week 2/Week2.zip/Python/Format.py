num1= float (input ("Enter a number with decimal"))
print ("The num with 3 digit decimal is %0.3f" %num1)
print ("The formated number with coma", format(num1, ","))
