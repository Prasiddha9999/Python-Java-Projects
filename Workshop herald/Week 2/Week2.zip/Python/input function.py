last_name= input("Enter your last name ")
age = int(input("Enter your age "))
current_temperature = float(input ("Enter the current temperature in Celsius "))

print("Your last name is ", last_name)
print("Your age is ", age )
print("The current temp is ",current_temperature, "Celsius")