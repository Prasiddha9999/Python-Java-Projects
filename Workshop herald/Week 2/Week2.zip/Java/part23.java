public class Part112 {

    public static void main(String[] args) {
        System.out.printf("John Doe\n");
        System.out.printf("123 Dudley Street\n");
        System.out.printf("123 Dudley Street\n");
     
    }
}