public class Part18

{

public static void main(String[] args) {
String forename= ("Prasiddha"); 
for(int i=1; i <= 5; i++){

System.out.println("Your forename is "+forename);
        }
    }
}