public class Part112 {

    public static void main(String[] args) {
        double num= 4580.5034;
        System.out.printf("%.3f", num);
     
    }
}