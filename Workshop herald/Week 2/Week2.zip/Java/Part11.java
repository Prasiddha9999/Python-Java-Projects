public class Part11{
    public static void main(String[] args){
    float length = 9;
    float width = 7;
    float perimeter = 2*(length+width);
    System.out.println("The perimeter is " +perimeter);
    }
}