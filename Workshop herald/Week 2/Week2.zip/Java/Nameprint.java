public class Nameprint
{
    public static void main(String[] arg){
    
    System.out.printf("John Doe \n123 Dudley Street \n123 Dudley Street\n");
    
    int k = 5;
    int num = 0;
    int num1 = num + k * 2;
    int num2 = num + k * 2;
    System.out.println("\n" + num1);
    System.out.println(num2);
    
    }
}