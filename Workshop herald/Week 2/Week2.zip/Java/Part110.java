public class Part19

{

public static void main(String[] args) {
String forename= ("Prasiddha Regmi"); 
{
System.out.printf("%15s", forename);
        }
    }
}