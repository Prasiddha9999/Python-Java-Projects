public class Part112 {

    public static void main(String[] args) {
        int k = 5;
        int num = 0;
        int num1 = num + k * 2;
        int num2 = num + k * 2;
     System.out.println("num is "+num);
    }
}
// num is 0
// num 1 is equal to num 2