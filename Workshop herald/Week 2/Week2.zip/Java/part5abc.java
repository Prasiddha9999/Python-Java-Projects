public class Part112 {

    public static void main(String[] args) {
    String last_name = System.console().readLine("Enter a last name");
    String age = System.console().readLine("Enter your age");
    String current_temperature = System.console().readLine("Enter the current temperature");
    System.out.println("The last name is"+last_name);
    System.out.println("The age is"+age);
    System.out.println("The current temperature is"+current_temperature);
    }
}