public class Part112 {

    public static void main(String[] args) {
        double num1 = 4580.5034;
        double num2 = 0.00000046004;
        double num3 = 5000402.0000000006;
        System.out.format("%.2f    ", num1);
        System.out.format("%.2f    ", num2);
        System.out.format("%.2f    ", num3);
    }
}