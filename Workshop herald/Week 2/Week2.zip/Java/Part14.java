
public class Part14{
    public static void main(String[] args){
    System.out.print("Java is great,"); 
    System.out.println("but not as wild as Python.");
    }
}