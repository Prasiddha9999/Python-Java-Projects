public class Part12{
    public static void main(String[] args){
    String name = ("Prasiddha Regmi");
    System.out.println("Your name is" +name);
    }
}