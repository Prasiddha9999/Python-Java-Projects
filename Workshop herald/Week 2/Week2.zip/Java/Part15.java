
public class Part15{
    public static void main(String[] args){
    int beth = 57;
    int tom = 34;
    int diff = (beth-tom);
    System.out.println("The difference between Beth’s age and Tom’s is "+diff);
    }
}