import java.lang.Math;
public class Part12{
    public static void main(String[] args){
    float max =  Math.max(5, 2);
    System.out.println("Max number is "+ max);
    }
}