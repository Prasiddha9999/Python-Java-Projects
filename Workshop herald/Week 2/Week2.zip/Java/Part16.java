
public class Part16{
    public static void main(String[] args){
    int num = 57;
    int value = (num^10);
    System.out.println("2 to the 10th power is "+value);
    }
}