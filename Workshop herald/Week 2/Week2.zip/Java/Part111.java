public class Part112 {

    public static void main(String[] args) {
        double num = Math.PI;

        System.out.format("%.5f", num);
    }
}