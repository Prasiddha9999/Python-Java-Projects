product = 1
num = int(input("Enter a number : "))
while product!=0:
    product = int(input ('Enter number to multiply : '))
    product = product * num
    print("The product is : ",product)
    
            
