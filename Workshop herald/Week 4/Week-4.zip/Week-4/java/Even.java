public class Main {
public static void main(String[] args){
	int sum = 0;
for (int x=100; x<=200; x++) {
	if (x % 2 == 0){
		sum= sum + x;
		}
	}
		System.out.println("The sum of number is: " +sum);
}
}







	
	




