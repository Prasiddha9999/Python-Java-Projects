
import java.util.*;
public class Main {
public static void main(String[] args){
Scanner sc = new Scanner(System.in);
System.out.println("Enter the number of college credit earned: ");
int str = sc.nextInt();
{
	if (str >= 90){
	System.out.println("Senior Status");
	}
else if (str >= 60){
	System.out.println("Junior Status");
	}
else if (str >= 30){
	System.out.println("Sophomore Status");
	}
	else
	{
	    System.out.println("Freshman Status");
			}
		}
	}
}



	
	




