
import java.util.*;
public class Main {
public static void main(String[] args){
Scanner sc = new Scanner(System.in);
System.out.println("Enter the number: ");
int str = sc.nextInt();
{
	if (str % 3 == 0){
	System.out.println("Fizz");
	}
else if (str % 5 == 0){
	System.out.println("Buzz");
	}
	else
	{
	    System.out.println("FizzBuzz");
			}
		}
	}
}



	
	




