public class Main {
public static void main(String[] args){
	int sum = 0;
for (int x=0; x<100; x++){
		sum= sum + x;
		}
	
	System.out.println("The sum of number is: " +sum);
}
}







	
	




