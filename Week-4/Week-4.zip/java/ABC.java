import java.util.*;
public class Main {
public static void main(String[] args){
Scanner sc = new Scanner(System.in);
System.out.println("Enter A or B or C: ");
String str = sc.nextLine();
{
	if (str.equals("A")){
	System.out.println("Apple");
	}
else if (str.equals("B")){
	System.out.println("ball");
	}
else if (str.equals("C")){
	System.out.println("Cat");
	}
	else
	{
	    System.out.println("Run Again");
			}
		}
	}
}



	
	




