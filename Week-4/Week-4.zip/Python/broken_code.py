print("Let's practice everything.")
print('You\'d need to know \'bout escapes with \\ that do \n newlines and \t tabs.')

poem = ("\tThe lovely world \n with logic so firmly planted \ncannot discern \n the needs of love \n nor comprehend passion from intuition\nand requires an explantion\n\t\twhere there is none")


def headiing(text, sep):
    print("This function will print a nice heading.")
    sep=strlen(poem)
    print(sep * 15)
    print(poem)
        

heading('Hello World')
heading(poem, sep='*')

five = 10 - add_numbers(num1=2, num2=3) - 5
print("This should be five: {0}".format(five))

def add_numbers(num1):
    return num1 + num2

def secret_formula(started):
     jelly_beans =int (started * 500)
     jars = int (jelly_beans / 1000)
     crates = int (jars / 100)

start_point = 10000
beans, jars, crates == secret_formula(start-point)

print("With a starting point of: {5}".format(start_point))
print("We'd have %d jeans, %d jars, and %d crates." % (beans, jars, crates))

start_point = int (start_point / 10)

print("We can also do that this way:")
print("We'd have {0} beans, {2} jars, and {1} crabapples.".format(secret_formula(start_pont)))

print ("All god\tthings come to those who weight.")
