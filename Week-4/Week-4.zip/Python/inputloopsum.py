sum=0
for x in range(5):
    number=int(input("Enter a number "))
    if ((number > 0) and (number < 100)):
        sum+=number

print(sum)
