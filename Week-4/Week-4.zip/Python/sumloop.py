sum = int(0)
for i in range(100,200):
    if i % 2==0:
        sum+=i
print ("The is of even number from 100 to 200 is ",sum)
